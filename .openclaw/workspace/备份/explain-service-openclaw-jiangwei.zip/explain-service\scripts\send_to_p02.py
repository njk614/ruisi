#!/usr/bin/env python3
import argparse
import json
import os
import sys
import time
import urllib.error
import urllib.request


DEFAULT_API_URL = "http://127.0.0.1:18900/send"
DEFAULT_TO_JID = "jiangwei@im.tuguan.net"
DEFAULT_FROM_ACCOUNT = "wangshanshan@im.tuguan.net"
TEXT_MESSAGE_DESCRIPTION = "【说明：当前消息最终发送给“数字人”，用于展示字幕和播报语音】"
IMAGE_MESSAGE_DESCRIPTION = "【说明：当前消息最终发送给“内容展示器”，用于展示图片PPT等内容】"


def result(status, message):
    print(json.dumps({"status": status, "message": message}, ensure_ascii=False, separators=(",", ":")))


def normalized_json(data):
    return json.dumps(data, ensure_ascii=False, separators=(",", ":"), sort_keys=True)


def format_body(message):
    if message.get("action") == "display_text":
        description = TEXT_MESSAGE_DESCRIPTION
    elif message.get("action") == "show_image":
        description = IMAGE_MESSAGE_DESCRIPTION
    else:
        description = "【说明：当前消息由讲解服务流程Skill转发】"
    return f"{description}\n\n{normalized_json(message)}"


def parse_args():
    parser = argparse.ArgumentParser(description="Forward explain JSON to P02 through XMPP send API.")
    parser.add_argument("--payload", help="Raw explain JSON. If omitted, stdin is used.")
    parser.add_argument("--dry-run", action="store_true", help="Validate and build messages without sending.")
    return parser.parse_args()


def load_payload(raw):
    try:
        payload = json.loads(raw)
    except json.JSONDecodeError:
        return None, "无效的 JSON 格式"
    if not isinstance(payload, dict):
        return None, "无效的 JSON 格式"
    return payload, None


def require_string(payload, key):
    value = payload.get(key)
    if value is None or str(value).strip() == "":
        return None
    return str(value)


def require_present(payload, key):
    value = payload.get(key)
    if value is None:
        return None
    if isinstance(value, str) and value.strip() == "":
        return None
    return value


def build_messages(payload):
    msg_type = require_string(payload, "type")
    if msg_type is None:
        return None, "缺少必要字段: type"
    if msg_type != "explain":
        return None, "type 不是 explain"

    text = require_string(payload, "text")
    if text is None:
        return None, "缺少必要字段: text"

    image_id = require_string(payload, "image_id")
    if image_id is None:
        return None, "缺少必要字段: image_id"

    duration = require_present(payload, "duration")
    if duration is None:
        return None, "缺少必要字段: duration"

    pagination = require_present(payload, "pagination")
    if pagination is None:
        return None, "缺少必要字段: pagination"

    image_path = str(payload.get("image_path") or "")
    description = str(payload.get("description") or "")

    text_message = {
        "action": "display_text",
        "duration": duration,
        "pagination": pagination,
        "source": "explain_skill",
        "text": text,
    }
    image_message = {
        "action": "show_image",
        "description": description,
        "duration": duration,
        "image_id": image_id,
        "image_path": image_path,
        "pagination": pagination,
        "source": "explain_skill",
    }
    return [text_message, image_message], None


def post_json(url, payload, token=None, timeout=5):
    body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    request = urllib.request.Request(url, data=body, headers=headers, method="POST")
    with urllib.request.urlopen(request, timeout=timeout) as response:
        content = response.read().decode("utf-8")
    if not content:
        return {}
    try:
        return json.loads(content)
    except json.JSONDecodeError:
        return {"raw": content}


def send_with_retry(message):
    api_url = os.environ.get("XMPP_SEND_API_URL") or DEFAULT_API_URL
    to_jid = os.environ.get("P02_JID") or DEFAULT_TO_JID
    from_account = os.environ.get("XMPP_FROM_ACCOUNT") or DEFAULT_FROM_ACCOUNT
    token = os.environ.get("XMPP_SEND_API_TOKEN") or None
    request_payload = {
        "jid": to_jid,
        "body": format_body(message),
        "from": from_account,
    }

    last_error = None
    for attempt in range(2):
        try:
            response = post_json(api_url, request_payload, token=token)
            if response.get("success") is True:
                return True, response
            last_error = response.get("error") or response
        except (OSError, urllib.error.URLError, TimeoutError) as exc:
            last_error = str(exc)
        if attempt == 0:
            time.sleep(0.3)
    return False, last_error


def main():
    args = parse_args()
    raw = args.payload if args.payload is not None else sys.stdin.read()
    if not raw or not raw.strip():
        result("failed", "无效的 JSON 格式")
        return 1

    payload, error = load_payload(raw)
    if error:
        result("failed", error)
        return 1

    messages, error = build_messages(payload)
    if error:
        result("failed", error)
        return 1

    if args.dry_run:
        result("success", "讲解已推送")
        return 0

    for message in messages:
        ok, _detail = send_with_retry(message)
        if not ok:
            result("failed", "向 P02 发送失败")
            return 1

    result("success", "讲解已推送")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
