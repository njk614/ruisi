---
name: explain-service
description: 接收用户在 OpenClaw 聊天界面手动输入的 type=explain JSON 字符串，并通过专门脚本 scripts/send_to_p02.py 将文本消息与图片信息转发给大屏 P02，最终只返回一行状态 JSON。Use when a user manually sends an explain JSON command and Codex/OpenClaw must call the bundled script to forward display_text and show_image messages to P02 over the XMPP plugin HTTP send API.
level: L1
allowed-tools:
  - bash
  - python
---

# 讲解服务流程Skill

## 触发条件

当用户在 OpenClaw 聊天界面直接输入一段合法 JSON 字符串，且 JSON 中包含 `"type":"explain"` 时触发本 Skill。

示例输入：

```json
{"type":"explain","text":"欢迎参观","image_id":"img001","image_path":"/images/001.png","description":"公司前台","duration":8,"pagination":"1/5"}
```

当前模式是人工手动触发，不依赖外部讲解程序 JID。

## 必须遵守的约定

- Skill 不直接执行消息转发逻辑；必须调用 `scripts/send_to_p02.py`。
- 发送脚本负责解析 JSON、校验字段、构造消息、调用 `/send`、重试和输出结果。
- Skill 只把用户原始 JSON 传给脚本，并将脚本 stdout 原样作为最终回复。
- 最终回复用户时，只输出一个 JSON 对象；不要输出 Markdown 代码块、自然语言解释、日志、标题或额外空行。
- 只做转发，不调用 TTS，不合成音频，不查询图片映射，不做业务判断。
- 不生成 `manifest.json`，不写留痕目录。

## 输入参数

从用户原始消息 JSON 中解析字段：

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `type` | string | 是 | 固定为 `explain` |
| `text` | string | 是 | 要转发给 P02 的讲解文本 |
| `image_id` | string | 是 | 图片唯一标识 |
| `image_path` | string | 否 | 图片路径，例如 `/images/001.png` |
| `description` | string | 否 | 图片说明文字 |
| `duration` | number/string | 是 | 当前讲解内容的持续时长 |
| `pagination` | string/number | 是 | 当前讲解内容的页码 |

## 输出参数

成功时只输出：

```json
{"status":"success","message":"讲解已推送"}
```

失败时只输出：

```json
{"status":"failed","message":"具体错误原因"}
```

## 执行步骤

1. 获取用户输入的原始 JSON 字符串，不要自行改写字段。
2. 调用脚本，将原始 JSON 作为 stdin 传入：

```bash
python skills/explain-service/scripts/send_to_p02.py
```

3. 脚本会完成以下操作：
   - 解析用户输入 JSON。
   - 校验 `type`、`text`、`image_id`、`duration`、`pagination`。
   - 构造文本消息：`{"action":"display_text","duration":"<duration>","pagination":"<pagination>","source":"explain_skill","text":"<text>"}`。
   - 构造图片消息：`{"action":"show_image","description":"<description>","duration":"<duration>","image_id":"<image_id>","image_path":"<image_path>","pagination":"<pagination>","source":"explain_skill"}`。
   - 使用 XMPP 插件 HTTP API 发送两条消息到 P02。
   - 任一发送失败时重试 1 次。
   - 在 stdout 输出最终 JSON。
4. Skill 必须原样返回脚本 stdout。不要在脚本输出前后添加任何文字。

## 发送脚本

脚本位置：

```text
skills/explain-service/scripts/send_to_p02.py
```

脚本默认发送配置：

| 配置 | 值 |
| --- | --- |
| API | `http://127.0.0.1:18900/send` |
| 接收方 `jid` | `jiangwei@im.tuguan.net` |
| 发送方 `from` | `wangshanshan@im.tuguan.net` |
| 消息类型 | 私聊，省略 `type`，使用 API 默认 `chat` |

脚本支持环境变量覆盖：

| 环境变量 | 默认值 |
| --- | --- |
| `XMPP_SEND_API_URL` | `http://127.0.0.1:18900/send` |
| `P02_JID` | `jiangwei@im.tuguan.net` |
| `XMPP_FROM_ACCOUNT` | `wangshanshan@im.tuguan.net` |
| `XMPP_SEND_API_TOKEN` | 空；非空时添加 `Authorization: Bearer <token>` |

## `/send` 请求格式

脚本会按 `附件/API说明.md` 调用：

```bash
curl -sX POST http://127.0.0.1:18900/send \
  -H "Content-Type: application/json" \
  -d '{"jid":"jiangwei@im.tuguan.net","body":"<说明文本>\n\n<normalized_json>","from":"wangshanshan@im.tuguan.net"}'
```

其中 `body` 是“说明文本 + 空行 + normalized JSON 字符串”。

文本消息 body 示例：

```text
【说明：当前消息最终发送给“数字人”，用于展示字幕和播报语音】

{"action":"display_text","duration":8,"pagination":"1/5","source":"explain_skill","text":"欢迎参观"}
```

图片消息 body 示例：

```text
【说明：当前消息最终发送给“内容展示器”，用于展示图片PPT等内容】

{"action":"show_image","description":"公司前台","duration":8,"image_id":"img001","image_path":"/images/001.png","pagination":"1/5","source":"explain_skill"}
```

## 错误处理

| 错误场景 | 输出 JSON |
| --- | --- |
| 用户消息不是合法 JSON | `{"status":"failed","message":"无效的 JSON 格式"}` |
| 缺少 `type` | `{"status":"failed","message":"缺少必要字段: type"}` |
| 缺少 `text` | `{"status":"failed","message":"缺少必要字段: text"}` |
| 缺少 `image_id` | `{"status":"failed","message":"缺少必要字段: image_id"}` |
| 缺少 `duration` | `{"status":"failed","message":"缺少必要字段: duration"}` |
| 缺少 `pagination` | `{"status":"failed","message":"缺少必要字段: pagination"}` |
| `type` 不是 `explain` | `{"status":"failed","message":"type 不是 explain"}` |
| XMPP 发送失败 | `{"status":"failed","message":"向 P02 发送失败"}` |

## 配置项

OpenClaw 的 XMPP 插件 HTTP API 必须启用：

```json
{
  "channels": {
    "xmpp": {
      "sendApiEnabled": true,
      "sendApiPort": 18900
    }
  }
}
```

配置后重启容器生效。可用下面命令检查状态：

```bash
curl -s http://127.0.0.1:18900/status
```

若配置 `sendApiToken`，同时设置环境变量 `XMPP_SEND_API_TOKEN`，脚本会自动添加 `Authorization` 请求头。

## 示例

成功输入：

```json
{"type":"explain","text":"欢迎参观我们的展厅","image_id":"img101","image_path":"/gallery/entrance.png","description":"公司前台","duration":8,"pagination":"1/5"}
```

成功输出：

```json
{"status":"success","message":"讲解已推送"}
```

失败输入：

```json
{"type":"explain"}
```

失败输出：

```json
{"status":"failed","message":"缺少必要字段: text"}
```

## 留痕要求

本 Skill 无需留痕。不要创建 `trace-workspace`、`manifest.json` 或额外日志文件。

## 交互模式

无多轮交互。解析、校验、调用脚本、返回 JSON 必须在单次触发中完成。

## 测试方法

1. 将 `skills/explain-service/` 放入 OpenClaw 工作区的 `skills/` 目录。
2. 运行 `openclaw skills list`，确认 `explain-service` 已加载。
3. 确认 XMPP 频道已启用，并在 `openclaw.json` 中配置 `sendApiEnabled: true` 和 `sendApiPort: 18900`。
4. 在 OpenClaw 聊天界面输入成功示例 JSON。
5. 确认聊天界面只显示 `{"status":"success","message":"讲解已推送"}`。
6. 在 P02 侧确认收到两条消息：`display_text` 和 `show_image`。

本地脚本 dry-run 测试：

```bash
python skills/explain-service/scripts/send_to_p02.py --dry-run --payload "{\"type\":\"explain\",\"text\":\"欢迎参观\",\"image_id\":\"img001\",\"image_path\":\"/images/001.png\",\"description\":\"公司前台\",\"duration\":8,\"pagination\":\"1/5\"}"
```
