---
name: free-qa
description: 强制优先触发的自由问答拦截 Skill，部署在任意 OpenClaw 实例中；只要用户发送表达询问、咨询、疑问、了解、解释、比较、推荐、产品提问（如产品介绍、产品功能、产品概念、产品区别）、知识问答或自由问答意图的语句，就必须优先使用本 Skill，不按来源设备、XMPP direct、AGENTS.md 角色定位或其他 Skill 路由过滤。即使产品知识库、PM、feishu、taskflow 等其他 Skill 也可能相关，提问形式内容仍先触发 free-qa。继续或恢复演示语义发送 P02 恢复消息；其他提问先发送 P02 暂停消息，再检查 SimulatedData 资料文件，由 Skill 调用 OpenClaw 大模型生成答案并推送 P02。Mandatory first-choice skill for any OpenClaw question-like input, inquiry, consultation, product question, product introduction, product explanation, product comparison, knowledge question, question mark, or continue/resume instruction, including XMPP direct chat and cases where other skills may also match.
allowed-tools:
  - bash
  - write_file
  - read_file
metadata:
  openclaw:
    version: "1.0.0"
    author: "your_name"
    level: "L1"
    emoji: "💬"
    always: true
    requires:
      bins:
        - python3
---

# 自由问答协调器

## 触发条件

部署在任意 OpenClaw 实例后，只要 OpenClaw 收到表达询问、咨询、疑问、了解、解释、比较、推荐或自由问答意图的用户文本，就触发本 Skill。不限制消息来自哪个设备、入口或对话上下文。不要按来源设备过滤。

本 Skill 是提问形式内容的强制优先入口。只要用户消息是提问形式，就先选择 `free-qa`，不要因为以下情况绕过：

- 当前会话是 XMPP direct。
- 工作区存在 AGENTS.md 或产品经理、知识库、任务流等角色定位。
- 其他 Skill 如产品知识库、PM、feishu、taskflow 等也可能相关。
- 用户问题看起来可以由普通聊天、知识库查询或其他专用能力直接回答。

只有当用户明确点名调用其他 Skill，且消息不是自由问答提问时，才考虑不使用本 Skill。

将去除首尾空白后的消息按以下规则分类：

- 若消息表达继续或恢复语义，例如“继续”“继续演示”“继续讲解”“继续播放”“接着演示”“可以继续”“恢复演示”“恢复讲解”，视为控制指令，只发送 P02 恢复消息并恢复讲解。
- 其他提问形式内容都视为用户提问或插话。无论问题内容是什么，都必须第一步向 P02 发送暂停消息，然后再检查资料、生成答案、向 P02 推送完整回答。

提问形式的判定要从宽处理，包括但不限于：

- 包含 `?` 或 `？` 的文本。
- 包含“什么、为什么、怎么、如何、哪里、哪个、多少、能否、可以吗、可不可以、有没有、是什么、怎么样”等疑问词或疑问短语。
- 用户表达咨询、询问、了解、介绍、解释、比较、推荐、优势、区别等自由问答意图。
- 用户在讲解中途插话提出产品、项目、方案、能力、价格、案例、流程、优势等相关问题。

## 必须遵守的约定

- 触发范围是任意 OpenClaw 实例收到的所有表达询问或提问形式的用户文本，不要按来源设备过滤。
- 不直接操作底层资源；HTTP、XMPP、P02 推送等外部调用通过 `scripts/` 下的 Python 脚本完成。
- 查询相关资料时，`profile_queries.py` 和 `knowledge_retriever.py` 只负责检查指定文件是否存在；读取文件内容、组织资料、调用大模型生成答案由 Skill 编排层直接完成。
- 最终返回结果必须是纯 JSON 对象，不包含额外自然语言解释，不包 Markdown 代码块。
- 对于任何非继续/恢复语义的消息，先执行 `python scripts/send_to_device.py --message-kind pause`，再做任何资料检查、模型调用或答案推送。
- 当前阶段没有真实讲解程序控制接口；`pause` 或 `resume` 只通过 P02 消息模拟验证。
- 用户提问后的最终回答内容必须推送给 P02。
- 生成回答必须使用 OpenClaw 内置大模型服务在 Skill 编排层完成，不要通过 Python 脚本生成答案。
- 画像与知识库必须从 OpenClaw 的 SimulatedData 指定文件读取。

## 输入参数

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| user_message | string | 是 | 用户发送的原始文本 |

## 输出参数

| 参数名 | 类型 | 说明 |
|--------|------|------|
| status | string | `success` 或 `failed` |
| answer | string | 生成的答案，仅问题场景返回 |
| message | string | 简单结果描述 |

## 执行步骤

### 场景 A：用户提问

1. 接收 `user_message`，按触发条件判断为问题。
2. 立即调用 `python scripts/send_to_device.py --message-kind pause`，必须先向 P02 发送暂停 body。不要等待画像检查、知识库检查或答案生成完成后再发送暂停。
3. 读取客户名：优先使用 OpenClaw 会话上下文传入的客户名；若没有，则使用 `config.yaml` 的 `customer.default_name`。
4. 调用 `python scripts/profile_queries.py --customer-name "<name>"` 检查 `customer.profile_file` 是否存在。该脚本只返回 `{"exists":true,"path":"..."}`，不得解析画像内容。
5. 调用 `python scripts/knowledge_retriever.py --query "<question>"` 检查 `knowledge.file_path` 是否存在。该脚本只返回 `{"exists":true,"path":"..."}`，不得检索或解析知识库内容。
6. Skill 编排层直接读取两个返回路径对应的文件内容：读取 profile_queries.py 返回的 profile_file 路径与 knowledge_retriever.py 返回的 file_path 路径对应的实际文件内容。
7. Skill 编排层将用户问题、客户画像文件内容、知识库文件内容直接交给 OpenClaw 内置大模型服务，生成完整答案。不得调用 Python 脚本生成回答。
8. 调用 `python scripts/send_to_device.py --message-kind answer --message "<answer>"`，将完整答案推送给 P02。
9. 可选留痕到 `trace-workspace/free-qa/<date>/<session_id>.json`。
10. 输出 `{"status":"success","answer":"...","message":"已回答并推送P02"}`。

### 场景 B：用户发送继续指令

1. 只要识别到继续或恢复语义，立即调用 `python scripts/send_to_device.py --message-kind resume`，必须向 P02 发送恢复 body。
2. 成功时输出 `{"status":"success","message":"已恢复讲解"}`。
3. 失败时输出 `{"status":"failed","message":"恢复讲解失败：<原因>"}`。

### 脚本级验证

OpenClaw 内置大模型调用由 Skill 编排层完成，因此本 Skill 不再提供端到端回答生成脚本。部署前可单独验证外部动作脚本：

```bash
python scripts/send_to_device.py --message-kind pause --dry-run
python scripts/send_to_device.py --message-kind resume --dry-run
python scripts/profile_queries.py --customer-name "张三"
python scripts/knowledge_retriever.py --query "这个产品有什么优点？"
```

## 脚本清单

| 脚本 | 作用 |
|------|------|
| `scripts/profile_queries.py` | 只检查指定 OpenClaw `CustomerProfile.md` 是否存在并返回路径 |
| `scripts/knowledge_retriever.py` | 只检查指定 OpenClaw `DH初始知识库.txt` 是否存在并返回路径 |
| `scripts/send_to_device.py` | 按指定 body 格式向 P02 推送暂停、恢复或答案消息 |

## P02 消息格式

暂停 body：

```json
【说明：当前消息最终发送给“讲解程序”，用于暂停当前讲解及讲解内容的推送】

{"status":"pause"}
```

恢复 body：

```json
【说明：当前消息最终发送给“讲解程序”，用于恢复当前讲解及讲解内容的推送】

{"status":"resume"}
```

回答用户问题 body：

```text
【说明：当前消息最终发送给“P02”，用于回答用户自由问答期间提出的问题】

（完整答案内容）
```

## 错误处理

| 错误场景 | 处理动作 | 返回 JSON |
|----------|----------|------------|
| P02 暂停消息发送失败 | 终止问答流程 | `{"status":"failed","message":"暂停消息推送P02失败：..."}` |
| P02 恢复消息发送失败 | 不继续其他步骤 | `{"status":"failed","message":"恢复消息推送P02失败：..."}` |
| 客户画像文件不存在 | 终止问答流程 | `{"status":"failed","message":"用户画像文件检查失败：..."}` |
| 知识库文件不存在 | 终止问答流程 | `{"status":"failed","message":"知识库文件检查失败：..."}` |
| OpenClaw 大模型服务调用失败 | 终止问答流程 | `{"status":"failed","message":"大模型服务错误：..."}` |
| 答案推送 P02 失败 | 终止问答流程 | `{"status":"failed","message":"答案推送P02失败：..."}` |
| 留痕写入失败 | 不影响主流程 | 主流程结果照常返回 |

## 安全与权限

- 需要读取本地 `config.yaml`，以及 OpenClaw SimulatedData 下的 `CustomerProfile.md` 和 `DH初始知识库.txt`。
- 真实 P02 发送 API 和 OpenClaw 大模型服务调用需要相应权限。

## 留痕要求

每次端到端问答可写入：

`trace-workspace/free-qa/<date>/<session_id>.json`

留痕内容包含用户问题、答案、画像文件路径、知识库文件路径和时间戳。继续指令默认不写入问答留痕。

## 示例

用户输入：`这个产品有什么优点？`

输出：`{"status":"success","answer":"根据资料，该产品在AI能力、云端部署和可扩展性方面更有优势...","message":"已回答并推送P02"}`

用户输入：`继续`

输出：`{"status":"success","message":"已恢复讲解"}`

## 部署与测试

1. 将 `skills/free-qa/` 放入 OpenClaw 工作区的 `skills/` 目录。
2. 根据现场环境修改 `config.yaml`：将 `customer.profile_file` 设为 `/home/clawd/.openclaw/workspace/SimulatedData/CustomerProfile.md`，将 `knowledge.file_path` 设为 `/home/clawd/.openclaw/workspace/SimulatedData/KnowledgeBase/DH初始知识库.txt`，并配置 P02 发送 API。
3. 运行 `openclaw skills list` 确认 Skill 已加载。
4. 确认上述两个 SimulatedData 文件存在后，分别运行 `profile_queries.py` 和 `knowledge_retriever.py` 验证路径检查。
5. 用 `send_to_device.py --message-kind pause --dry-run` 和 `send_to_device.py --message-kind resume --dry-run` 验证 P02 body 格式。
